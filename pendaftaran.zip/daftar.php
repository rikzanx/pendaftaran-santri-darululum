<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Fonts -->
    <link rel="dns-prefetch" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Raleway:300,400,600" rel="stylesheet" type="text/css">

    <link rel="stylesheet" href="css/style.css">

    <link rel="icon" href="Favicon.png">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">

    <title>Pendafataran</title>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-light navbar-laravel">
    <div class="container">
        <a class="navbar-brand" href="#">Kembali</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="index.php">Login</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="daftar.php">Pendaftaran</a>
                </li>
            </ul>

        </div>
    </div>
</nav>

<main class="login-form">
    <div class="cotainer">
        <div class="row justify-content-center">
            <div class="col-md-8 text-center">
                <h1>Pendaftaran Santri Baru Asrama Ar-Risalah</h1>
                <h1>Pondok Pesantren Darul 'Ulum Jombang</h1>
                <p>Prosedur Pendaftaran Online</p>
                <p>
                    1. Transfer biaya pendaftaran sebesar 200.000 ke Rek . BCA 92891891<br>
                    2. Pilih menu Pendafataran isi : Nama Lengkap, Email, dan Bukti Pembayaran. <br>
                    3. Tunggu untuk mendapatkan kode. <br>
                    4. Apabila sudah memiliki kode silahkan pilih menu login, kemudian mengisi formulir.
                </p>

            </div>
        </div>
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Pendaftaran</div>
                    <div class="card-body">
                        <form id="formdaftar">
                            <div class="form-group row">
                                <label for="nama" class="col-md-4 col-form-label text-md-right">Nama Santri</label>
                                <div class="col-md-6">
                                    <input type="text" id="nama" class="form-control" name="nama" required autofocus>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="email" class="col-md-4 col-form-label text-md-right">Email/No Hp</label>
                                <div class="col-md-6">
                                    <input type="text" id="email" class="form-control" name="email" required autofocus>
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-md-4">
                                    
                                </div>
                                <div class="col-md-6">
                                    <img id="img" height="150" src="images/gambar.png">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="buktipendaftaran" class="col-md-4 col-form-label text-md-right">Bukti Pembayaran</label>
                                <div class="col-md-6">
                                    <div class="custom-file">
                                    <input type="file" class="custom-file-input" id="buktipendaftaran">
                                    <label class="custom-file-label" for="buktipendaftaran">Choose <fieldset></fieldset></label>
                                  </div>
                                </div>
                            </div>
                         </form>
                            <div class="col-md-6 offset-md-4">
                                <button class="btn btn-primary" id="daftar">
                                    Daftar
                                </button>
                                <a href="index.php" class="btn btn-default">Login</a>
                            </div>
                    </div>
                    
                </div>
            </div>
        </div>
    </div>
    </div>

</main>
</body>
<script src="vendor/jquery/jquery.min.js"></script>
<script type="text/javascript">
    var gambar="0";
    function readFile() {
  
          if (this.files && this.files[0]) {
            
            var FR= new FileReader();
            
            FR.addEventListener("load", function(e) {
              document.getElementById("img").src       = e.target.result;
              
              gambar= e.target.result;

            }); 
            
            FR.readAsDataURL( this.files[0] );
          }
          
        }

        document.getElementById("buktipendaftaran").addEventListener("change", readFile);
    $(document).ready(function(){
        
        $("#daftar").click(function(){
            var data= $('#formdaftar').serialize();

            if(gambar=="0")
            {
                alert('gambar kosong');
            }else{
                data=data+"&image="+encodeURIComponent(gambar);
                console.log(data);
                $.ajax({
                url:'aksi-daftar.php',
                type: 'POST',
                dataType: 'JSON',
                data: data,
                success:function(responses){
                    if(responses.status == "ok")
                    {
                        alert('Sukses daftar silahkan tunggu kode yang kami kirim lewat Telepon atau Email');
                        window.location="index.php";
                    }else{
                        alert('Gagal Daftar hub admin');
                    }
                    
                },
            });
            }
        });
    });
</script>
</html>